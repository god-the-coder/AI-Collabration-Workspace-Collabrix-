from rest_framework import serializers

from apps.accounts.models import UserModel
from apps.audit.models import EventLog


class ActivityActorSerializer(serializers.ModelSerializer):
    """
    Minimal user representation for the actor field on EventLog.
    Mirrors ProfileSerializer from notifications but kept independent
    to avoid coupling between the two modules.
    """
    avatar = serializers.SerializerMethodField()

    class Meta:
        model = UserModel
        fields = ["id", "first_name", "last_name", "avatar"]

    def get_avatar(self, obj):
        if obj.avatar:
            return obj.avatar.file.url
        return None


class EventLogSerializer(serializers.ModelSerializer):
    actor = ActivityActorSerializer(read_only=True)

    class Meta:
        model = EventLog
        fields = [
            "id",
            "actor",
            "event_type",
            "title",
            "description",
            "resource_type",
            "resource_id",
            "metadata",
            "created_at",
        ]
