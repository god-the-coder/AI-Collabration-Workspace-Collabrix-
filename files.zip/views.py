from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.conf import settings
from config.settings import base

from .serializers import RegisterSerializers, UserResponseSerializer, LoginSerializers
from .services import AuthService


class RegisterAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    def post(self, request):
        # BUG FIX: original try: block was dedented one level causing
        # IndentationError at module import time — entire app failed to start.
        try:
            serializer = RegisterSerializers(data=request.data)
            serializer.is_valid(raise_exception=True)

            result = AuthService.register_user(serializer.validated_data)

            return Response(
                {
                    "message": "Account created successfully",
                    "user": UserResponseSerializer(result["user"]).data,
                },
                status=status.HTTP_201_CREATED,
            )
        except Exception as e:
            print(type(e))
            print(e)
            raise


class LoginAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    def post(self, request):
        try:
            serializer = LoginSerializers(data=request.data)
            serializer.is_valid(raise_exception=True)

            email = serializer.validated_data["email"]
            password = serializer.validated_data["password"]

            user = AuthService.login_user(email, password)

            session = AuthService.create_session(user=user, request=request)
            token = AuthService.generate_token(user=user, session=session)

            is_secure = not settings.DEBUG

            response = Response(
                {
                    "message": "User logged in successfully",
                    "user": UserResponseSerializer(user).data,
                },
                status=status.HTTP_200_OK,
            )

            response.set_cookie(
                key="access_token",
                value=token["access"],
                httponly=True,
                secure=is_secure,
                samesite='Lax',
                max_age=base.SIMPLE_JWT["ACCESS_TOKEN_LIFETIME"].total_seconds(),
            )

            response.set_cookie(
                key="refresh_token",
                value=token["refresh"],
                httponly=True,
                secure=is_secure,
                samesite="Lax",
                max_age=base.SIMPLE_JWT["REFRESH_TOKEN_LIFETIME"].total_seconds(),
            )

            return response

        except Exception as e:
            print(type(e))
            print(e)
            raise
