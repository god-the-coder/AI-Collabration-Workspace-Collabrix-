from django.urls import path
from .views import WorkspaceActivityView

urlpatterns = [
    path(
        "workspace/<uuid:workspace_id>/",
        WorkspaceActivityView.as_view(),
        name="workspace-activity",
    ),
]
