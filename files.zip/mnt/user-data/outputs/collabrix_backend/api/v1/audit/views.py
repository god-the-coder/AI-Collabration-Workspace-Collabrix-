from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404

from apps.workspaces.models import Workspace
from apps.audit.models import EventType, EventResourceType
from apps.audit.services import ActivityService
from .serializers import EventLogSerializer


class WorkspaceActivityView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, workspace_id):
        try:
            workspace = get_object_or_404(Workspace, id=workspace_id)

            # Membership check — same pattern used in NotificationService.project_created
            # workspace.members is the related manager confirmed from notification service
            if not workspace.members.filter(user=request.user).exists():
                return Response(
                    {"detail": "You are not a member of this workspace."},
                    status=status.HTTP_403_FORBIDDEN,
                )

            # --- Query param parsing ---
            event_type = request.query_params.get("event_type")
            resource_type = request.query_params.get("resource_type")

            try:
                limit = min(int(request.query_params.get("limit", 30)), 100)
                if limit < 1:
                    raise ValueError
            except (ValueError, TypeError):
                return Response(
                    {"detail": "limit must be a positive integer (max 100)."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # --- Validate event_type if provided ---
            if event_type and event_type not in EventType.values:
                return Response(
                    {
                        "detail": f"Invalid event_type '{event_type}'.",
                        "valid_values": EventType.values,
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # --- Validate resource_type if provided ---
            if resource_type and resource_type not in EventResourceType.values:
                return Response(
                    {
                        "detail": f"Invalid resource_type '{resource_type}'.",
                        "valid_values": EventResourceType.values,
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            logs = ActivityService.get_workspace_activity(
                workspace,
                event_type=event_type,
                resource_type=resource_type,
                limit=limit,
            )

            serializer = EventLogSerializer(logs, many=True)

            return Response(
                {
                    "workspace_id": str(workspace_id),
                    "count": len(serializer.data),
                    "activity": serializer.data,
                },
                status=status.HTTP_200_OK,
            )

        except Exception as e:
            print(type(e), e)
            raise
