from apps.audit.models import EventLog, EventType, EventResourceType


class ActivityService:
    """
    Central service for writing and reading EventLog entries.

    Callers (workspace, project, task services) import this and call
    ActivityService.log(...) whenever a meaningful business event occurs.
    Keeping this at apps/audit/ avoids cross-layer imports from api/v1/.
    """

    @staticmethod
    def log(
        *,
        workspace,
        actor,
        event_type: str,
        title: str,
        description: str,
        resource_type: str,
        resource_id,
        metadata: dict = None,
    ) -> EventLog:
        """
        Create a single EventLog entry.

        All arguments are keyword-only to prevent silent argument-order bugs
        at call sites, since the signature is long.

        `resource_id` must be the UUID primary key of the resource.
        `metadata` is an optional dict for any extra context (e.g. old/new values).
        """
        return EventLog.objects.create(
            workspace=workspace,
            actor=actor,
            event_type=event_type,
            title=title,
            description=description,
            resource_type=resource_type,
            resource_id=resource_id,
            metadata=metadata or {},
        )

    @staticmethod
    def get_workspace_activity(
        workspace,
        *,
        event_type: str = None,
        resource_type: str = None,
        limit: int = 30,
    ):
        """
        Return recent EventLog entries for a workspace, newest first.

        Optional filters:
          event_type     — one of EventType values
          resource_type  — one of EventResourceType values
          limit          — capped at call site (view enforces max 100)
        """
        qs = (
            EventLog.objects
            .filter(workspace=workspace)
            .select_related("actor")
            .order_by("-created_at")
        )

        if event_type:
            qs = qs.filter(event_type=event_type)

        if resource_type:
            qs = qs.filter(resource_type=resource_type)

        return qs[:limit]
