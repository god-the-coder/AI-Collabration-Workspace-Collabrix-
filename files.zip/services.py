from django.db import transaction
from django.utils import timezone
from django.contrib.auth import authenticate
from django.conf import settings

from rest_framework.exceptions import AuthenticationFailed
from rest_framework_simplejwt.tokens import RefreshToken

from apps.accounts.models import UserModel, SessionsModel, UserSettingsModel


class AuthService:

    @staticmethod
    @transaction.atomic
    def register_user(validated_data):
        validated_data.pop("confirm_password")
        password = validated_data.pop("password")

        user = UserModel(**validated_data)
        user.set_password(password)
        user.save()

        # BUG FIX: UserSettingsModel was never created, causing user.settings
        # to raise RelatedObjectDoesNotExist everywhere it was accessed.
        # Created inside the same transaction.atomic block so a settings
        # failure rolls back the user creation too.
        UserSettingsModel.objects.create(user=user)

        return {"user": user}

    @staticmethod
    def login_user(email, password):
        user = authenticate(email=email, password=password)

        if user is None:
            raise AuthenticationFailed("Invalid user or password")

        if not user.is_active:
            raise AuthenticationFailed("Your account has been deactivated")

        user.last_login = timezone.now()
        user.save(update_fields=["last_login"])

        return user

    @staticmethod
    def generate_token(user, session):
        refresh = RefreshToken.for_user(user)
        refresh["session_id"] = str(session.id)
        session.refresh_token = str(refresh)
        session.save(update_fields=["refresh_token"])

        return {
            "access": str(refresh.access_token),
            "refresh": str(refresh),
        }

    @staticmethod
    def create_session(user, request):
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')

        if x_forwarded_for:
            # BUG FIX: was split[','][0] (subscript) — TypeError at runtime.
            # Correct call syntax is split(',')[0].
            ip_address = x_forwarded_for.split(',')[0].strip()
        else:
            ip_address = request.META.get('REMOTE_ADDR')

        session = SessionsModel.objects.create(
            user=user,
            ip_address=ip_address,
            user_agent=request.META.get('HTTP_USER_AGENT'),
            expires_at=timezone.now() + settings.SIMPLE_JWT["REFRESH_TOKEN_LIFETIME"],
        )

        return session
